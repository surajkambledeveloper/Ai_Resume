// import React, { useState } from 'react';
// import './Edit.css';
// import html2pdf from 'html2pdf.js';

// const Edit = () => {
//   const [resumeData, setResumeData] = useState({
//     name: 'Aditya Tiwary',
//     role: 'Experienced Business Analyst | Supply Chain Optimization | Data Analytics',
//     phone: '+44 20 7123 4567',
//     email: '',
//     linkedin: 'linkedin.com',
//     location: 'Birmingham',
//     summary: 'With over 9 years of experience in business analysis, supply chain management, and logistics, I have a proven record of reducing costs while enhancing efficiency and customer satisfaction. My expertise includes running advanced business models, financial reporting, and streamlining processes to refine supply chain operations. I am eager to contribute to your commitment to sustainability and the journey to net zero.',
//     experience: [
//       {
//         company: 'Unilever',
//         location: 'London, UK',
//         title: 'Supply Chain Analyst',
//         startDate: '01/2019',
//         endDate: '12/2022',
//         achievements: [
//           'Led a cross-functional team to streamline logistics processes, reducing overall supply chain costs by 15% within a 12-month period.',
//           'Optimized inventory levels through improved forecasting accuracy, resulting in a 20% reduction in working capital requirements.',
//           'Managed supplier performance and initiated strategic partnerships which enhanced raw material availability by 25%.',
//           'Developed robust business models in Excel, simulating various supply scenarios to improve decision-making efficiencies.',
//           'Implemented an AIMMS-based planning solution that improved logistics scheduling, enhancing customer satisfaction rates by 30%.',
//           'Contributed to a company-wide sustainability initiative aimed at reducing environmental impact, in line with the journey to net-zero emissions.'
//         ]
//       },
//       {
//         company: 'GlaxoSmithKline',
//         location: 'Brentford, UK',
//         title: 'Logistics Coordinator',
//         startDate: '06/2016',
//         endDate: '12/2018',
//         achievements: [
//           'Coordinated shipping activities for pharmaceutical products, achieving a 99% on-time delivery record over two years.',
//           'Reduced freight costs by 10% through the negotiation of more favorable terms with logistics providers.',
//           'Managed a team responsible for ensuring compliance with international logistics and shipping regulations.',
//           'Collaborated with manufacturing teams to align production schedules with customer demand, ensuring optimal resource allocation.'
//         ]
//       }
//     ],
//     education: [
//       {
//         school: 'University of Warwick',
//         location: 'Coventry, UK',
//         degree: 'MSc Supply Chain and Logistics Management',
//         startDate: '01/2011',
//         endDate: '01/2012'
//       },
//       {
//         school: 'University of Leeds',
//         location: 'Leeds, UK',
//         degree: 'BSc Economics and Management',
//         startDate: '01/2008',
//         endDate: '01/2011'
//       }
//     ],
//     achievements: [
//       {
//         title: 'Team Lead for Sustainability Project',
//         description: 'Spearheaded a cross-functional team initiative that targeted a 15% carbon footprint reduction.'
//       },
//       {
//         title: 'Award for Logistics Excellence',
//         description: 'Received an internal accolade for outstanding work in logistics coordination'
//       },
//       {
//         title: 'Negotiation Success',
//         description: 'Renegotiated freight contracts, cutting transportation costs by 10%'
//       }
//     ],
//     skills: [
//       'Supply Chain Management',
//       'Logistics Planning',
//       'Business Process Optimization',
//       'Data Analysis',
//       'Financial Reporting',
//       'Microsoft Office'
//     ],
//     courses: [
//       {
//         title: 'Advanced Excel for Productivity',
//         description: 'Certification program by Corporate Finance Institute, sharpening my data analysis and modeling skills for robust business decision-making.'
//       },
//       {
//         title: 'SAP Supply Chain Management',
//         description: 'Focused training on supply chain processes via SAP SCM provided by the SAP Training and Certification Shop.'
//       }
//     ]
//   });

//   const [showButtons, setShowButtons] = useState(true);
//   const [photo, setPhoto] = useState(null);
//   const [branding, setBranding] = useState(false);
//   const [sectionSettings, setSectionSettings] = useState({
//     header: {
//       showTitle: true,
//       showPhone: true,
//       showLink: true,
//       showEmail: true,
//       showLocation: true,
//       uppercaseName: false,
//       showPhoto: true
//     },
//     summary: { showSummary: true },
//     experience: { showExperience: true },
//     education: { showEducation: true },
//     achievements: { showAchievements: true },
//     skills: { showSkills: true },
//     courses: { showCourses: true }
//   });
//   const [activeSection, setActiveSection] = useState(null);
//   const [hoveredSection, setHoveredSection] = useState(null);
//   const [sectionsOrder, setSectionsOrder] = useState([
//     'summary',
//     'experience',
//     'education',
//     'achievements',
//     'skills',
//     'courses'
//   ]);

//   const handleInputChange = (section, field, value, index = null) => {
//     if (index !== null) {
//       const updatedSection = [...resumeData[section]];
//       updatedSection[index][field] = value;
//       setResumeData({ ...resumeData, [section]: updatedSection });
//     } else {
//       setResumeData({ ...resumeData, [field]: value });
//     }
//   };

//   const handleAddSection = (section) => {
//     const newItem = {
//       company: '',
//       location: '',
//       title: '',
//       startDate: '',
//       endDate: '',
//       achievements: []
//     };

//     if (section === 'education') {
//       newItem.school = '';
//       newItem.degree = '';
//     } else if (section === 'achievements') {
//       newItem.title = '';
//       newItem.description = '';
//     } else if (section === 'courses') {
//       newItem.title = '';
//       newItem.description = '';
//     }

//     setResumeData({
//       ...resumeData,
//       [section]: [...resumeData[section], newItem]
//     });
//   };

//   const handleRemoveSection = (section, index) => {
//     const updatedSection = [...resumeData[section]];
//     updatedSection.splice(index, 1);
//     setResumeData({ ...resumeData, [section]: updatedSection });
//   };

//   const handleDownload = () => {
//     setShowButtons(false);
//     setTimeout(() => {
//       const resumeContent = document.getElementById("resumeContent");
//       const options = {
//         filename: "resume.pdf",
//         html2canvas: { scale: 2 },
//         jsPDF: { unit: "mm", format: "a4", orientation: "portrait" },
//       };
//       html2pdf()
//         .from(resumeContent)
//         .set(options)
//         .save()
//         .then(() => {
//           setShowButtons(true);
//         });
//     }, 100);
//   };

//   const handleShare = () => {
//     const resumeLink = window.location.href;
//     navigator.clipboard.writeText(resumeLink)
//       .then(() => alert('Link copied to clipboard!'))
//       .catch(() => alert('Failed to copy link to clipboard.'));
//   };

//   const handleUploadResume = () => {
//     const input = document.createElement('input');
//     input.type = 'file';
//     input.accept = 'application/pdf';
//     input.onchange = (e) => {
//       const file = e.target.files[0];
//       if (file) {
//         alert('PDF uploaded successfully. Backend logic will be implemented.');
//       }
//     };
//     input.click();
//   };

//   const handleCameraClick = () => {
//     const input = document.createElement('input');
//     input.type = 'file';
//     input.accept = 'image/*';
//     input.onchange = (e) => {
//       const file = e.target.files[0];
//       if (file) {
//         const reader = new FileReader();
//         reader.onload = (event) => {
//           setPhoto(event.target.result);
//         };
//         reader.readAsDataURL(file);
//       }
//     };
//     input.click();
//   };

//   const handleSettingChange = (section, setting) => {
//     setSectionSettings({
//       ...sectionSettings,
//       [section]: {
//         ...sectionSettings[section],
//         [setting]: !sectionSettings[section][setting]
//       }
//     });
//   };

//   const handleBrandingToggle = () => {
//     setBranding(!branding);
//   };

//   const handleSectionClick = (section) => {
//     setActiveSection(section);
//   };

//   const handleSectionHover = (section) => {
//     setHoveredSection(section);
//   };

//   const handleSectionLeave = () => {
//     setHoveredSection(null);
//   };

//   const handleMoveSectionUp = (index) => {
//     if (index > 0) {
//       const newOrder = [...sectionsOrder];
//       [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
//       setSectionsOrder(newOrder);
//     }
//   };

//   const handleMoveSectionDown = (index) => {
//     if (index < sectionsOrder.length - 1) {
//       const newOrder = [...sectionsOrder];
//       [newOrder[index + 1], newOrder[index]] = [newOrder[index], newOrder[index + 1]];
//       setSectionsOrder(newOrder);
//     }
//   };

//   const renderSectionSettings = (section) => {
//     const settings = sectionSettings[section];
//     return (
//       <div className="settings-modal">
//         <h3>{section.charAt(0).toUpperCase() + section.slice(1)} Settings</h3>
//         {Object.keys(settings).map((key) => (
//           <label key={key}>
//             <span>{key.replace('show', '').replace(/([A-Z])/g, ' $1').trim()}</span>
//             <input
//               type="checkbox"
//               checked={settings[key]}
//               onChange={() => handleSettingChange(section, key)}
//             />
//           </label>
//         ))}
//       </div>
//     );
//   };

//   return (
//     <div className="app-container">
//       <div className="sidebar">
//         <button className="sidebar-btn" onClick={() => alert('Add Section functionality will be implemented here.')}>🔄 Add Section</button>
//         <button className="sidebar-btn" onClick={() => setActiveSection('rearrange')}>↕️ Rearrange</button>
//         <button className="sidebar-btn">📄 Templates</button>
//         <button className="sidebar-btn" onClick={() => alert('Design & Font functionality will be implemented here.')}>🎨 Design & Font</button>
//         <hr />
//         <button className="sidebar-btn" onClick={() => alert('Improve Text functionality will be implemented here.')}>✅ Improve Text</button>
//         <button className="sidebar-btn">📋 ATS Check</button>
//         <button className="sidebar-btn">🤖 AI Assistant</button>
//         <hr />
//         <button className="sidebar-btn premium" onClick={handleDownload}>⬇️ Download</button>
//         <button className="sidebar-btn" onClick={handleShare}>🔗 Share</button>
//         <button className="sidebar-btn premium">📜 History</button>
//         <label className="toggle-branding">
//           Branding <input type="checkbox" checked={branding} onChange={handleBrandingToggle} />
//         </label>
//         <button className="upload-btn" onClick={handleUploadResume}>⬆️ Upload Resume</button>
//       </div>

//       <div className="main-content">
//         <div className="resume-container" id="resumeContent">
//           <div className="header">
//             <h1
//               contentEditable
//               onBlur={(e) => handleInputChange(null, 'name', e.target.textContent)}
//               style={{ position: 'relative', cursor: 'pointer' }}
//               onClick={() => handleSectionClick('header')}
//               onMouseEnter={() => handleSectionHover('header')}
//               onMouseLeave={handleSectionLeave}
//             >
//               {sectionSettings.header.uppercaseName ? resumeData.name.toUpperCase() : resumeData.name}
//               {(hoveredSection === 'header' || activeSection === 'header') && (
//                 <span className="settings-icon" onClick={() => setActiveSection('header')}>⚙️</span>
//               )}
//             </h1>
//             {sectionSettings.header.showTitle && (
//               <p contentEditable onBlur={(e) => handleInputChange(null, 'role', e.target.textContent)}>
//                 {resumeData.role}
//               </p>
//             )}
//             <div className="contact-info">
//               {sectionSettings.header.showPhone && (
//                 <span contentEditable onBlur={(e) => handleInputChange(null, 'phone', e.target.textContent)}>
//                   {resumeData.phone}
//                 </span>
//               )}
//               {sectionSettings.header.showEmail && (
//                 <span contentEditable onBlur={(e) => handleInputChange(null, 'email', e.target.textContent)}>
//                   {resumeData.email}
//                 </span>
//               )}
//               {sectionSettings.header.showLink && (
//                 <span contentEditable onBlur={(e) => handleInputChange(null, 'linkedin', e.target.textContent)}>
//                   {resumeData.linkedin}
//                 </span>
//               )}
//               {sectionSettings.header.showLocation && (
//                 <span contentEditable onBlur={(e) => handleInputChange(null, 'location', e.target.textContent)}>
//                   {resumeData.location}
//                 </span>
//               )}
//             </div>
//           </div>

//           {sectionSettings.header.showPhoto && photo && (
//             <div className="photo-section">
//               <img src={photo} alt="Profile" style={{ width: '100px', height: '100px', borderRadius: '50%' }} />
//             </div>
//           )}

//           {sectionsOrder.map((section, index) => {
//             if (sectionSettings[section].showSummary && section === 'summary') {
//               return (
//                 <div className="section" key={section}>
//                   <h2
//                     onClick={() => handleSectionClick(section)}
//                     onMouseEnter={() => handleSectionHover(section)}
//                     onMouseLeave={handleSectionLeave}
//                   >
//                     Summary
//                     {(hoveredSection === section || activeSection === section) && (
//                       <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
//                     )}
//                   </h2>
//                   <p contentEditable onBlur={(e) => handleInputChange(null, 'summary', e.target.textContent)}>
//                     {resumeData.summary}
//                   </p>
//                 </div>
//               );
//             }

//             if (sectionSettings[section].showExperience && section === 'experience') {
//               return (
//                 <div className="section" key={section}>
//                   <h2
//                     onClick={() => handleSectionClick(section)}
//                     onMouseEnter={() => handleSectionHover(section)}
//                     onMouseLeave={handleSectionLeave}
//                   >
//                     Experience
//                     {(hoveredSection === section || activeSection === section) && (
//                       <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
//                     )}
//                   </h2>
//                   {resumeData.experience.map((exp, index) => (
//                     <div key={index} className="experience-item">
//                       <h3 contentEditable onBlur={(e) => handleInputChange('experience', 'company', e.target.textContent, index)}>
//                         {exp.company}
//                       </h3>
//                       <p contentEditable onBlur={(e) => handleInputChange('experience', 'location', e.target.textContent, index)}>
//                         {exp.location}
//                       </p>
//                       <p contentEditable onBlur={(e) => handleInputChange('experience', 'title', e.target.textContent, index)}>
//                         {exp.title}
//                       </p>
//                       <p contentEditable onBlur={(e) => handleInputChange('experience', 'startDate', e.target.textContent, index)}>
//                         {exp.startDate} - {exp.endDate}
//                       </p>
//                       <ul>
//                         {exp.achievements.map((achievement, i) => (
//                           <li key={i} contentEditable onBlur={(e) => {
//                             const updatedAchievements = [...exp.achievements];
//                             updatedAchievements[i] = e.target.textContent;
//                             handleInputChange('experience', 'achievements', updatedAchievements, index);
//                           }}>
//                             {achievement}
//                           </li>
//                         ))}
//                       </ul>
//                       {showButtons && (
//                         <button onClick={() => handleRemoveSection('experience', index)}>Remove Experience</button>
//                       )}
//                     </div>
//                   ))}
//                   {showButtons && (
//                     <button onClick={() => handleAddSection('experience')}>Add Experience</button>
//                   )}
//                 </div>
//               );
//             }

//             if (sectionSettings[section].showEducation && section === 'education') {
//               return (
//                 <div className="section" key={section}>
//                   <h2
//                     onClick={() => handleSectionClick(section)}
//                     onMouseEnter={() => handleSectionHover(section)}
//                     onMouseLeave={handleSectionLeave}
//                   >
//                     Education
//                     {(hoveredSection === section || activeSection === section) && (
//                       <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
//                     )}
//                   </h2>
//                   {resumeData.education.map((edu, index) => (
//                     <div key={index} className="education-item">
//                       <h3 contentEditable onBlur={(e) => handleInputChange('education', 'school', e.target.textContent, index)}>
//                         {edu.school}
//                       </h3>
//                       <p contentEditable onBlur={(e) => handleInputChange('education', 'location', e.target.textContent, index)}>
//                         {edu.location}
//                       </p>
//                       <p contentEditable onBlur={(e) => handleInputChange('education', 'degree', e.target.textContent, index)}>
//                         {edu.degree}
//                       </p>
//                       <p contentEditable onBlur={(e) => handleInputChange('education', 'startDate', e.target.textContent, index)}>
//                         {edu.startDate} - {edu.endDate}
//                       </p>
//                       {showButtons && (
//                         <button onClick={() => handleRemoveSection('education', index)}>Remove Education</button>
//                       )}
//                     </div>
//                   ))}
//                   {showButtons && (
//                     <button onClick={() => handleAddSection('education')}>Add Education</button>
//                   )}
//                 </div>
//               );
//             }

//             if (sectionSettings[section].showAchievements && section === 'achievements') {
//               return (
//                 <div className="section" key={section}>
//                   <h2
//                     onClick={() => handleSectionClick(section)}
//                     onMouseEnter={() => handleSectionHover(section)}
//                     onMouseLeave={handleSectionLeave}
//                   >
//                     Key Achievements
//                     {(hoveredSection === section || activeSection === section) && (
//                       <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
//                     )}
//                   </h2>
//                   {resumeData.achievements.map((achievement, index) => (
//                     <div key={index} className="achievement-item">
//                       <h3 contentEditable onBlur={(e) => handleInputChange('achievements', 'title', e.target.textContent, index)}>
//                         {achievement.title}
//                       </h3>
//                       <p contentEditable onBlur={(e) => handleInputChange('achievements', 'description', e.target.textContent, index)}>
//                         {achievement.description}
//                       </p>
//                       {showButtons && (
//                         <button onClick={() => handleRemoveSection('achievements', index)}>Remove Achievement</button>
//                       )}
//                     </div>
//                   ))}
//                   {showButtons && (
//                     <button onClick={() => handleAddSection('achievements')}>Add Achievement</button>
//                   )}
//                 </div>
//               );
//             }

//             if (sectionSettings[section].showSkills && section === 'skills') {
//               return (
//                 <div className="section" key={section}>
//                   <h2
//                     onClick={() => handleSectionClick(section)}
//                     onMouseEnter={() => handleSectionHover(section)}
//                     onMouseLeave={handleSectionLeave}
//                   >
//                     Skills
//                     {(hoveredSection === section || activeSection === section) && (
//                       <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
//                     )}
//                   </h2>
//                   <ul>
//                     {resumeData.skills.map((skill, index) => (
//                       <li key={index} contentEditable onBlur={(e) => {
//                         const updatedSkills = [...resumeData.skills];
//                         updatedSkills[index] = e.target.textContent;
//                         setResumeData({ ...resumeData, skills: updatedSkills });
//                       }}>
//                         {skill}
//                       </li>
//                     ))}
//                   </ul>
//                   {showButtons && (
//                     <button onClick={() => handleAddSection('skills')}>Add Skill</button>
//                   )}
//                 </div>
//               );
//             }

//             if (sectionSettings[section].showCourses && section === 'courses') {
//               return (
//                 <div className="section" key={section}>
//                   <h2
//                     onClick={() => handleSectionClick(section)}
//                     onMouseEnter={() => handleSectionHover(section)}
//                     onMouseLeave={handleSectionLeave}
//                   >
//                     Courses
//                     {(hoveredSection === section || activeSection === section) && (
//                       <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
//                     )}
//                   </h2>
//                   {resumeData.courses.map((course, index) => (
//                     <div key={index} className="course-item">
//                       <h3 contentEditable onBlur={(e) => handleInputChange('courses', 'title', e.target.textContent, index)}>
//                         {course.title}
//                       </h3>
//                       <p contentEditable onBlur={(e) => handleInputChange('courses', 'description', e.target.textContent, index)}>
//                         {course.description}
//                       </p>
//                       {showButtons && (
//                         <button onClick={() => handleRemoveSection('courses', index)}>Remove Course</button>
//                       )}
//                     </div>
//                   ))}
//                   {showButtons && (
//                     <button onClick={() => handleAddSection('courses')}>Add Course</button>
//                   )}
//                 </div>
//               );
//             }

//             return null;
//           })}
//         </div>

//         {branding && (
//           <div className="branding">
//             Made by Aditya Tiwary
//           </div>
//         )}

//         {activeSection === 'rearrange' && (
//           <div className="settings-modal-overlay">
//             <div className="settings-modal">
//               <h3>Rearrange Sections</h3>
//               {sectionsOrder.map((section, index) => (
//                 <div key={section} className="rearrange-item">
//                   <span>{section.charAt(0).toUpperCase() + section.slice(1)}</span>
//                   <div>
//                     <button onClick={() => handleMoveSectionUp(index)}>⬆️</button>
//                     <button onClick={() => handleMoveSectionDown(index)}>⬇️</button>
//                   </div>
//                 </div>
//               ))}
//               <button onClick={() => setActiveSection(null)}>Close</button>
//             </div>
//           </div>
//         )}

//         {activeSection && activeSection !== 'rearrange' && (
//           <div className="settings-modal-overlay">
//             <div className="settings-modal">
//               <h3>{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)} Settings</h3>
//               {Object.keys(sectionSettings[activeSection]).map((key) => (
//                 <label key={key}>
//                   <span>{key.replace('show', '').replace(/([A-Z])/g, ' $1').trim()}</span>
//                   <input
//                     type="checkbox"
//                     checked={sectionSettings[activeSection][key]}
//                     onChange={() => handleSettingChange(activeSection, key)}
//                   />
//                 </label>
//               ))}
//               <button onClick={() => setActiveSection(null)}>Close</button>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Edit;

import React, { useState } from 'react';
import './Edit.css';
import html2pdf from 'html2pdf.js';

const Edit = () => {
  const [resumeData, setResumeData] = useState({
    name: 'Aditya Tiwary',
    role: 'Experienced Business Analyst | Supply Chain Optimization | Data Analytics',
    phone: '+44 20 7123 4567',
    email: '',
    linkedin: 'linkedin.com',
    location: 'Birmingham',
    summary: 'With over 9 years of experience in business analysis, supply chain management, and logistics, I have a proven record of reducing costs while enhancing efficiency and customer satisfaction. My expertise includes running advanced business models, financial reporting, and streamlining processes to refine supply chain operations. I am eager to contribute to your commitment to sustainability and the journey to net zero.',
    experience: [
      {
        company: 'Unilever',
        location: 'London, UK',
        title: 'Supply Chain Analyst',
        startDate: '01/2019',
        endDate: '12/2022',
        achievements: [
          'Led a cross-functional team to streamline logistics processes, reducing overall supply chain costs by 15% within a 12-month period.',
          'Optimized inventory levels through improved forecasting accuracy, resulting in a 20% reduction in working capital requirements.',
          'Managed supplier performance and initiated strategic partnerships which enhanced raw material availability by 25%.',
          'Developed robust business models in Excel, simulating various supply scenarios to improve decision-making efficiencies.',
          'Implemented an AIMMS-based planning solution that improved logistics scheduling, enhancing customer satisfaction rates by 30%.',
          'Contributed to a company-wide sustainability initiative aimed at reducing environmental impact, in line with the journey to net-zero emissions.'
        ]
      },
      {
        company: 'GlaxoSmithKline',
        location: 'Brentford, UK',
        title: 'Logistics Coordinator',
        startDate: '06/2016',
        endDate: '12/2018',
        achievements: [
          'Coordinated shipping activities for pharmaceutical products, achieving a 99% on-time delivery record over two years.',
          'Reduced freight costs by 10% through the negotiation of more favorable terms with logistics providers.',
          'Managed a team responsible for ensuring compliance with international logistics and shipping regulations.',
          'Collaborated with manufacturing teams to align production schedules with customer demand, ensuring optimal resource allocation.'
        ]
      }
    ],
    education: [
      {
        school: 'University of Warwick',
        location: 'Coventry, UK',
        degree: 'MSc Supply Chain and Logistics Management',
        startDate: '01/2011',
        endDate: '01/2012'
      },
      {
        school: 'University of Leeds',
        location: 'Leeds, UK',
        degree: 'BSc Economics and Management',
        startDate: '01/2008',
        endDate: '01/2011'
      }
    ],
    achievements: [
      {
        title: 'Team Lead for Sustainability Project',
        description: 'Spearheaded a cross-functional team initiative that targeted a 15% carbon footprint reduction.'
      },
      {
        title: 'Award for Logistics Excellence',
        description: 'Received an internal accolade for outstanding work in logistics coordination'
      },
      {
        title: 'Negotiation Success',
        description: 'Renegotiated freight contracts, cutting transportation costs by 10%'
      }
    ],
    skills: [
      'Supply Chain Management',
      'Logistics Planning',
      'Business Process Optimization',
      'Data Analysis',
      'Financial Reporting',
      'Microsoft Office'
    ],
    courses: [
      {
        title: 'Advanced Excel for Productivity',
        description: 'Certification program by Corporate Finance Institute, sharpening my data analysis and modeling skills for robust business decision-making.'
      },
      {
        title: 'SAP Supply Chain Management',
        description: 'Focused training on supply chain processes via SAP SCM provided by the SAP Training and Certification Shop.'
      }
    ]
  });

  const [showButtons, setShowButtons] = useState(true);
  const [photo, setPhoto] = useState(null);
  const [branding, setBranding] = useState(false);
  const [sectionSettings, setSectionSettings] = useState({
    header: {
      showTitle: true,
      showPhone: true,
      showLink: true,
      showEmail: true,
      showLocation: true,
      uppercaseName: false,
      showPhoto: true
    },
    summary: { showSummary: true },
    experience: { showExperience: true },
    education: { showEducation: true },
    achievements: { showAchievements: true },
    skills: { showSkills: true },
    courses: { showCourses: true }
  });
  const [activeSection, setActiveSection] = useState(null);
  const [hoveredSection, setHoveredSection] = useState(null);
  const [sectionsOrder, setSectionsOrder] = useState([
    'summary',
    'experience',
    'education',
    'achievements',
    'skills',
    'courses'
  ]);

  const handleInputChange = (section, field, value, index = null) => {
    if (index !== null) {
      const updatedSection = [...resumeData[section]];
      updatedSection[index][field] = value;
      setResumeData({ ...resumeData, [section]: updatedSection });
    } else {
      setResumeData({ ...resumeData, [field]: value });
    }
  };

  const handleAddSection = (section) => {
    const newItem = {
      company: '',
      location: '',
      title: '',
      startDate: '',
      endDate: '',
      achievements: []
    };

    if (section === 'education') {
      newItem.school = '';
      newItem.degree = '';
    } else if (section === 'achievements') {
      newItem.title = '';
      newItem.description = '';
    } else if (section === 'courses') {
      newItem.title = '';
      newItem.description = '';
    }

    setResumeData({
      ...resumeData,
      [section]: [...resumeData[section], newItem]
    });
  };

  const handleRemoveSection = (section, index) => {
    const updatedSection = [...resumeData[section]];
    updatedSection.splice(index, 1);
    setResumeData({ ...resumeData, [section]: updatedSection });
  };

  const handleDownload = () => {
    setShowButtons(false);
    setTimeout(() => {
      const resumeContent = document.getElementById("resumeContent");
      const options = {
        filename: "resume.pdf",
        html2canvas: { scale: 2 },
        jsPDF: { unit: "mm", format: "a4", orientation: "portrait", margin: [10, 10, 10, 10] }, // Adjusted margins
      };
      html2pdf()
        .from(resumeContent)
        .set(options)
        .save()
        .then(() => {
          setShowButtons(true);
        });
    }, 100);
  };

  const handleShare = () => {
    const resumeLink = window.location.href;
    navigator.clipboard.writeText(resumeLink)
      .then(() => alert('Link copied to clipboard!'))
      .catch(() => alert('Failed to copy link to clipboard.'));
  };

  const handleUploadResume = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'application/pdf';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        alert('PDF uploaded successfully. Backend logic will be implemented.');
      }
    };
    input.click();
  };

  const handleCameraClick = () => {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = 'image/*';
    input.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        const reader = new FileReader();
        reader.onload = (event) => {
          setPhoto(event.target.result);
        };
        reader.readAsDataURL(file);
      }
    };
    input.click();
  };

  const handleSettingChange = (section, setting) => {
    setSectionSettings({
      ...sectionSettings,
      [section]: {
        ...sectionSettings[section],
        [setting]: !sectionSettings[section][setting]
      }
    });
  };

  const handleBrandingToggle = () => {
    setBranding(!branding);
  };

  const handleSectionClick = (section) => {
    setActiveSection(section);
  };

  const handleSectionHover = (section) => {
    setHoveredSection(section);
  };

  const handleSectionLeave = () => {
    setHoveredSection(null);
  };

  const handleMoveSectionUp = (index) => {
    if (index > 0) {
      const newOrder = [...sectionsOrder];
      [newOrder[index - 1], newOrder[index]] = [newOrder[index], newOrder[index - 1]];
      setSectionsOrder(newOrder);
    }
  };

  const handleMoveSectionDown = (index) => {
    if (index < sectionsOrder.length - 1) {
      const newOrder = [...sectionsOrder];
      [newOrder[index + 1], newOrder[index]] = [newOrder[index], newOrder[index + 1]];
      setSectionsOrder(newOrder);
    }
  };

  const renderSectionSettings = (section) => {
    const settings = sectionSettings[section];
    return (
      <div className="settings-modal">
        <h3>{section.charAt(0).toUpperCase() + section.slice(1)} Settings</h3>
        {Object.keys(settings).map((key) => (
          <label key={key}>
            <span>{key.replace('show', '').replace(/([A-Z])/g, ' $1').trim()}</span>
            <input
              type="checkbox"
              checked={settings[key]}
              onChange={() => handleSettingChange(section, key)}
            />
          </label>
        ))}
      </div>
    );
  };

  return (
    <div className="app-container">
      <div className="sidebar">
        <button className="sidebar-btn" onClick={() => alert('Add Section functionality will be implemented here.')}>🔄 Add Section</button>
        <button className="sidebar-btn" onClick={() => setActiveSection('rearrange')}>↕️ Rearrange</button>
        <button className="sidebar-btn">📄 Templates</button>
        <button className="sidebar-btn" onClick={() => alert('Design & Font functionality will be implemented here.')}>🎨 Design & Font</button>
        <hr />
        <button className="sidebar-btn" onClick={() => alert('Improve Text functionality will be implemented here.')}>✅ Improve Text</button>
        <button className="sidebar-btn">📋 ATS Check</button>
        <button className="sidebar-btn">🤖 AI Assistant</button>
        <hr />
        <button className="sidebar-btn premium" onClick={handleDownload}>⬇️ Download</button>
        <button className="sidebar-btn" onClick={handleShare}>🔗 Share</button>
        <button className="sidebar-btn premium">📜 History</button>
        <label className="toggle-branding">
          Branding <input type="checkbox" checked={branding} onChange={handleBrandingToggle} />
        </label>
        <button className="upload-btn" onClick={handleUploadResume}>⬆️ Upload Resume</button>
      </div>

      <div className="main-content">
        <div className="resume-container" id="resumeContent">
          <div className="header">
            <h1
              contentEditable
              onBlur={(e) => handleInputChange(null, 'name', e.target.textContent)}
              style={{ position: 'relative', cursor: 'pointer' }}
              onClick={() => handleSectionClick('header')}
              onMouseEnter={() => handleSectionHover('header')}
              onMouseLeave={handleSectionLeave}
            >
              {sectionSettings.header.uppercaseName ? resumeData.name.toUpperCase() : resumeData.name}
              {(hoveredSection === 'header' || activeSection === 'header') && (
                <span className="settings-icon" onClick={() => setActiveSection('header')}>⚙️</span>
              )}
            </h1>
            {sectionSettings.header.showTitle && (
              <p contentEditable onBlur={(e) => handleInputChange(null, 'role', e.target.textContent)}>
                {resumeData.role}
              </p>
            )}
            <div className="contact-info">
              {sectionSettings.header.showPhone && (
                <span contentEditable onBlur={(e) => handleInputChange(null, 'phone', e.target.textContent)}>
                  {resumeData.phone}
                </span>
              )}
              {sectionSettings.header.showEmail && (
                <span contentEditable onBlur={(e) => handleInputChange(null, 'email', e.target.textContent)}>
                  {resumeData.email}
                </span>
              )}
              {sectionSettings.header.showLink && (
                <span contentEditable onBlur={(e) => handleInputChange(null, 'linkedin', e.target.textContent)}>
                  {resumeData.linkedin}
                </span>
              )}
              {sectionSettings.header.showLocation && (
                <span contentEditable onBlur={(e) => handleInputChange(null, 'location', e.target.textContent)}>
                  {resumeData.location}
                </span>
              )}
            </div>
          </div>

          {sectionSettings.header.showPhoto && photo && (
            <div className="photo-section">
              <img src={photo} alt="Profile" style={{ width: '100px', height: '100px', borderRadius: '50%' }} />
            </div>
          )}

          {sectionsOrder.map((section, index) => {
            if (sectionSettings[section].showSummary && section === 'summary') {
              return (
                <div className="section" key={section}>
                  <h2
                    onClick={() => handleSectionClick(section)}
                    onMouseEnter={() => handleSectionHover(section)}
                    onMouseLeave={handleSectionLeave}
                  >
                    Summary
                    {(hoveredSection === section || activeSection === section) && (
                      <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
                    )}
                  </h2>
                  <p contentEditable onBlur={(e) => handleInputChange(null, 'summary', e.target.textContent)}>
                    {resumeData.summary}
                  </p>
                </div>
              );
            }

            if (sectionSettings[section].showExperience && section === 'experience') {
              return (
                <div className="section" key={section}>
                  <h2
                    onClick={() => handleSectionClick(section)}
                    onMouseEnter={() => handleSectionHover(section)}
                    onMouseLeave={handleSectionLeave}
                  >
                    Experience
                    {(hoveredSection === section || activeSection === section) && (
                      <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
                    )}
                  </h2>
                  {resumeData.experience.map((exp, index) => (
                    <div key={index} className="experience-item">
                      <div className="details">
                        <h3 contentEditable onBlur={(e) => handleInputChange('experience', 'company', e.target.textContent, index)}>
                          {exp.company}
                        </h3>
                        <p contentEditable onBlur={(e) => handleInputChange('experience', 'title', e.target.textContent, index)}>
                          {exp.title}
                        </p>
                        <ul>
                          {exp.achievements.map((achievement, i) => (
                            <li key={i} contentEditable onBlur={(e) => {
                              const updatedAchievements = [...exp.achievements];
                              updatedAchievements[i] = e.target.textContent;
                              handleInputChange('experience', 'achievements', updatedAchievements, index);
                            }}>
                              {achievement}
                            </li>
                          ))}
                        </ul>
                      </div>
                      <div className="date-location">
                        <p contentEditable onBlur={(e) => handleInputChange('experience', 'location', e.target.textContent, index)}>
                          {exp.location}
                        </p>
                        <p contentEditable onBlur={(e) => handleInputChange('experience', 'startDate', e.target.textContent, index)}>
                          {exp.startDate} - {exp.endDate}
                        </p>
                      </div>
                      {showButtons && (
                        <button onClick={() => handleRemoveSection('experience', index)}>Remove Experience</button>
                      )}
                    </div>
                  ))}
                  {showButtons && (
                    <button onClick={() => handleAddSection('experience')}>Add Experience</button>
                  )}
                </div>
              );
            }

            if (sectionSettings[section].showEducation && section === 'education') {
              return (
                <div className="section" key={section}>
                  <h2
                    onClick={() => handleSectionClick(section)}
                    onMouseEnter={() => handleSectionHover(section)}
                    onMouseLeave={handleSectionLeave}
                  >
                    Education
                    {(hoveredSection === section || activeSection === section) && (
                      <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
                    )}
                  </h2>
                  {resumeData.education.map((edu, index) => (
                    <div key={index} className="education-item">
                      <div className="details">
                        <h3 contentEditable onBlur={(e) => handleInputChange('education', 'school', e.target.textContent, index)}>
                          {edu.school}
                        </h3>
                        <p contentEditable onBlur={(e) => handleInputChange('education', 'degree', e.target.textContent, index)}>
                          {edu.degree}
                        </p>
                      </div>
                      <div className="date-location">
                        <p contentEditable onBlur={(e) => handleInputChange('education', 'location', e.target.textContent, index)}>
                          {edu.location}
                        </p>
                        <p contentEditable onBlur={(e) => handleInputChange('education', 'startDate', e.target.textContent, index)}>
                          {edu.startDate} - {edu.endDate}
                        </p>
                      </div>
                      {showButtons && (
                        <button onClick={() => handleRemoveSection('education', index)}>Remove Education</button>
                      )}
                    </div>
                  ))}
                  {showButtons && (
                    <button onClick={() => handleAddSection('education')}>Add Education</button>
                  )}
                </div>
              );
            }

            if (sectionSettings[section].showAchievements && section === 'achievements') {
              return (
                <div className="section" key={section}>
                  <h2
                    onClick={() => handleSectionClick(section)}
                    onMouseEnter={() => handleSectionHover(section)}
                    onMouseLeave={handleSectionLeave}
                  >
                    Key Achievements
                    {(hoveredSection === section || activeSection === section) && (
                      <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
                    )}
                  </h2>
                  {resumeData.achievements.map((achievement, index) => (
                    <div key={index} className="achievement-item">
                      <h3 contentEditable onBlur={(e) => handleInputChange('achievements', 'title', e.target.textContent, index)}>
                        {achievement.title}
                      </h3>
                      <p contentEditable onBlur={(e) => handleInputChange('achievements', 'description', e.target.textContent, index)}>
                        {achievement.description}
                      </p>
                      {showButtons && (
                        <button onClick={() => handleRemoveSection('achievements', index)}>Remove Achievement</button>
                      )}
                    </div>
                  ))}
                  {showButtons && (
                    <button onClick={() => handleAddSection('achievements')}>Add Achievement</button>
                  )}
                </div>
              );
            }

            if (sectionSettings[section].showSkills && section === 'skills') {
              return (
                <div className="section" key={section}>
                  <h2
                    onClick={() => handleSectionClick(section)}
                    onMouseEnter={() => handleSectionHover(section)}
                    onMouseLeave={handleSectionLeave}
                  >
                    Skills
                    {(hoveredSection === section || activeSection === section) && (
                      <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
                    )}
                  </h2>
                  <ul>
                    {resumeData.skills.map((skill, index) => (
                      <li key={index} contentEditable onBlur={(e) => {
                        const updatedSkills = [...resumeData.skills];
                        updatedSkills[index] = e.target.textContent;
                        setResumeData({ ...resumeData, skills: updatedSkills });
                      }}>
                        {skill}
                      </li>
                    ))}
                  </ul>
                  {showButtons && (
                    <button onClick={() => handleAddSection('skills')}>Add Skill</button>
                  )}
                </div>
              );
            }

            if (sectionSettings[section].showCourses && section === 'courses') {
              return (
                <div className="section" key={section}>
                  <h2
                    onClick={() => handleSectionClick(section)}
                    onMouseEnter={() => handleSectionHover(section)}
                    onMouseLeave={handleSectionLeave}
                  >
                    Courses
                    {(hoveredSection === section || activeSection === section) && (
                      <span className="settings-icon" onClick={() => setActiveSection(section)}>⚙️</span>
                    )}
                  </h2>
                  {resumeData.courses.map((course, index) => (
                    <div key={index} className="course-item">
                      <h3 contentEditable onBlur={(e) => handleInputChange('courses', 'title', e.target.textContent, index)}>
                        {course.title}
                      </h3>
                      <p contentEditable onBlur={(e) => handleInputChange('courses', 'description', e.target.textContent, index)}>
                        {course.description}
                      </p>
                      {showButtons && (
                        <button onClick={() => handleRemoveSection('courses', index)}>Remove Course</button>
                      )}
                    </div>
                  ))}
                  {showButtons && (
                    <button onClick={() => handleAddSection('courses')}>Add Course</button>
                  )}
                </div>
              );
            }

            return null;
          })}
        </div>

        {branding && (
          <div className="branding">
            Made by Aditya Tiwary
          </div>
        )}

        {activeSection === 'rearrange' && (
          <div className="settings-modal-overlay">
            <div className="settings-modal">
              <h3>Rearrange Sections</h3>
              {sectionsOrder.map((section, index) => (
                <div key={section} className="rearrange-item">
                  <span>{section.charAt(0).toUpperCase() + section.slice(1)}</span>
                  <div>
                    <button onClick={() => handleMoveSectionUp(index)}>⬆️</button>
                    <button onClick={() => handleMoveSectionDown(index)}>⬇️</button>
                  </div>
                </div>
              ))}
              <button onClick={() => setActiveSection(null)}>Close</button>
            </div>
          </div>
        )}

        {activeSection && activeSection !== 'rearrange' && (
          <div className="settings-modal-overlay">
            <div className="settings-modal">
              <h3>{activeSection.charAt(0).toUpperCase() + activeSection.slice(1)} Settings</h3>
              {Object.keys(sectionSettings[activeSection]).map((key) => (
                <label key={key}>
                  <span>{key.replace('show', '').replace(/([A-Z])/g, ' $1').trim()}</span>
                  <input
                    type="checkbox"
                    checked={sectionSettings[activeSection][key]}
                    onChange={() => handleSettingChange(activeSection, key)}
                  />
                </label>
              ))}
              <button onClick={() => setActiveSection(null)}>Close</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Edit;