import React, { useState, useEffect } from "react";
import html2pdf from "html2pdf.js";
// import "./styles.css";

const templates = [
  { id: "tempA", image: "/images/templateA.png", alt: "Template A" },
  { id: "tempB", image: "/images/templateB.png", alt: "Template B" },
  { id: "tempC", image: "/images/templateC.png", alt: "Template C" },
];

const Helpforupload = () => {
  const [resumeFile, setResumeFile] = useState(null);
  const [message, setMessage] = useState("");
  const [extractedData, setExtractedData] = useState(null);
  const [selectedTemplate, setSelectedTemplate] = useState(
    localStorage.getItem("selectedTemplate") || "tempA"
  );
  const [generatedHTML, setGeneratedHTML] = useState(null);

  useEffect(() => {
    localStorage.setItem("selectedTemplate", selectedTemplate);
  }, [selectedTemplate]);

  const handleFileChange = (e) => {
    setResumeFile(e.target.files[0]);
  };

  const handleUpload = async (e) => {
    e.preventDefault();
    if (!resumeFile) {
      setMessage("Please select a file");
      return;
    }

    const formData = new FormData();
    formData.append("resume", resumeFile);
    formData.append("selectedTemplate", selectedTemplate);

    setMessage("Uploading and extracting data...");

    try {
      const response = await fetch("http://localhost:3000/upload", {
        method: "POST",
        body: formData,
      });
      const result = await response.json();
      if (result.success) {
        setMessage("Data extracted successfully!");
        setExtractedData(result.extractedData);
      } else {
        setMessage("Failed to extract data. Please try again.");
      }
    } catch (error) {
      setMessage("An error occurred. Please try again.");
      console.error(error);
    }
  };

  const handleTemplateSelect = (templateId) => {
    setSelectedTemplate(templateId);
  };

  const generatePdf = async () => {
    setMessage("Generating PDF...");
    try {
      const response = await fetch("http://localhost:3000/generateHtml", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          template: selectedTemplate,
          data: extractedData,
        }),
      });

      const result = await response.json();
      if (response.ok) {
        setGeneratedHTML(result.generatedHTML);
        setMessage("HTML generated successfully!");
        setTimeout(() => {
          html2pdf().from(document.getElementById("resumePreview")).save("resume.pdf");
        }, 500);
      } else {
        setMessage("Failed to generate HTML.");
      }
    } catch (error) {
      setMessage("An error occurred while generating the HTML.");
      console.error(error);
    }
  };

  return (
    <div className="container">
      <h1>Upload Your Resume</h1>
      <form onSubmit={handleUpload}>
        <input type="file" accept=".pdf" onChange={handleFileChange} required />
        <button type="submit">Upload & Extract Data</button>
      </form>
      <div className="message">{message}</div>

      {extractedData && (
        <div className="template-select">
          <h2>Select a Template:</h2>
          {templates.map((template) => (
            <img
              key={template.id}
              src={template.image}
              alt={template.alt}
              className={`template-image ${
                selectedTemplate === template.id ? "selected" : ""
              }`}
              onClick={() => handleTemplateSelect(template.id)}
            />
          ))}
          <button onClick={generatePdf}>Generate PDF</button>
        </div>
      )}

      {generatedHTML && (
        <div id="resumePreview" dangerouslySetInnerHTML={{ __html: generatedHTML }}></div>
      )}
    </div>
  );
};

export default Helpforupload;
